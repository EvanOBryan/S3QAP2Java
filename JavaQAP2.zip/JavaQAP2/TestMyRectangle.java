import Circle.MyPoint;

public class TestMyRectangle{
    public static void main(String[] args) {
        MyPoint topLeft=new MyPoint(1,4); //Provides the coordinates for the top left and bottom right points
        MyPoint bottomRight=new MyPoint(5,1);
        MyRectangle rectangle=new MyRectangle(topLeft, bottomRight);
        System.out.println(rectangle);
        System.out.println("Width of rectangle: "+rectangle.getWidth());
        System.out.println("Height of rectangle: "+rectangle.getHeight());
        System.out.println("Area of rectangle: "+rectangle.getArea());
        System.out.println("Perimeter of rectangle: "+rectangle.getPerimeter());
    }
}