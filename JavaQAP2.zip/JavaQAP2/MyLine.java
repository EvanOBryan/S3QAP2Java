import Circle.MyPoint;

public class MyLine {
    private MyPoint begin;
    private MyPoint end;

    public MyLine(int x1, int y1, int x2, int y2){
        begin=new MyPoint(x1,y1);
        end=new MyPoint(x2,y2);
    }
    public double getLength(){
        int dx=end.getX()-begin.getX(); //Length of line in X dimension
        int dy=end.getY()-begin.getY(); //Length of line in Y dimension
        return Math.sqrt(dx*dx+dy*dy); //True length of line using Pythagorean theorem
    }
    public double getGradient(){
        int dx=end.getX()-begin.getX(); //Same as above for obtaining length of line
        int dy=end.getY()-begin.getY();
        if(dx==0){
            return Double.POSITIVE_INFINITY; //In case of vertical line
        }else{
            return(double)dy/dx; //Gradient/slope of the line
        }
    }
}

