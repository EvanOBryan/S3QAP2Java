public class Money {
    private long dollars;
    private long cents;

    public Money(long dollars, long cents) {
        if (cents >= 100) {
            this.dollars = dollars + cents / 100;
            this.cents = cents % 100;
        } else {
            this.dollars = dollars;
            this.cents = cents;
        }
    }

    public Money(long dollars) {
        this(dollars, 0);
    }

    public Money(double amount) {
        this.dollars = (long) amount;
        this.cents = (long) ((amount - this.dollars) * 100);
    }

    public Money(Money money) {
        this(money.dollars, money.cents);
    }

    public long getDollars() {
        return dollars;
    }

    public long getCents() {
        return cents;
    }

    public void add(Money amount) {
        long totalCents = this.cents + amount.cents;
        this.dollars += amount.dollars + totalCents / 100;
        this.cents = totalCents % 100;
    }

    public void subtract(Money amount) {
        long totalCents1 = this.dollars * 100 + this.cents;
        long totalCents2 = amount.dollars * 100 + amount.cents;
        long totalCentsResult = totalCents1 - totalCents2;

        if (totalCentsResult < 0) {
            this.dollars = 0;
            this.cents = 0;
        } else {
            this.dollars = totalCentsResult / 100;
            this.cents = totalCentsResult % 100;
        }
    }

    public boolean exceeds(Money amount) {
        long totalCents1 = this.dollars * 100 + this.cents;
        long totalCents2 = amount.dollars * 100 + amount.cents;
        return totalCents1 > totalCents2;
    }

    public String toString() {
        return String.format("$%d.%02d", dollars, cents);
    }
}