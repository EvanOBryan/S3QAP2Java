public class CreditCard {
    private Person cardHolder;
    private Money balance;
    private Money creditLimit;

    public CreditCard(Person cardHolder, Money creditLimit) {
        this.cardHolder = cardHolder;
        this.balance = new Money(0, 0);
        this.creditLimit = new Money(creditLimit);
    }

    public void charge(Money amount) {
        Money newBalance = new Money(balance);
        newBalance.add(amount);

        if (!newBalance.exceeds(creditLimit)) {
            balance.add(amount);
            System.out.println("Charge: " + amount);
        } else {
            System.out.println("Exceeds credit limit");
        }
    }

    public void payment(Money amount) {
        balance.subtract(amount);
        System.out.println("Payment: " + amount);
    }

    public Money getBalance() {
        return new Money(balance);
    }

    public Money getCreditLimit() {
        return new Money(creditLimit);
    }

    public String getPersonals() {
        return cardHolder.toString();
    }


    public String toString() {
        return "CreditCard [Card Holder=" + cardHolder + ", Balance=" + balance + ", Credit Limit=" + creditLimit + "]";
    }
}