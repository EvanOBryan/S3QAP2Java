public class TesMyLine{
    public static void main(String[] args){
        MyLine line=new MyLine(1,2,4,6);
        System.out.println("Length of line: "+line.getLength());
        System.out.println("Gradient of line: "+line.getGradient());
    }
}